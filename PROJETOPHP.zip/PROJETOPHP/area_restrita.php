<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.html');
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8"/>
<title>Área Restrita</title>
<link rel="stylesheet" href="estilo.css"/>
</head>
<body>
<h2>Bem-vindo, <?php echo $_SESSION['username']; ?>!</h2>
<p>Você está logado na área restrita.</p>
<?php if ($_SESSION['funcao'] == 'administrador') { ?>
    <a href="admin.php">Área Administrativa</a><br><br>
<?php } ?>
<a href="logout.php">Sair</a>
</body>
</html>