<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['funcao'] != 'administrador') {
    header('Location: login.html');
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8"/>
<title>Admin - Sistema Web</title>
<link rel="stylesheet" href="estilo.css"/>
</head>
<body>
<h2>Área Administrativa</h2>
<ul>
  <li><a href="cadastro_projeto.html">Gerenciar Projetos</a></li>
  <li><a href="gerenciar_utilizadores.php">Gerenciar Utilizadores</a></li>
  <li><a href="cadastro_cliente.html">Gerenciar Clientes</a></li>
</ul>
<br>
<a href="area_restrita.php">Voltar</a>
</body>
</html>