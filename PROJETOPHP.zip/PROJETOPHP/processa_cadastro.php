<?php
$host='localhost:3306'; $user='root'; $db='empresa_web';

$conn = new mysqli(hostname: $host, username: $user,  database:$db);
if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}

$nome = $_POST['nome'];
$apelido = $_POST['apelido'];
$email = $_POST['email'];
$telefone = $_POST['telefone'];
$username = $_POST['username'];
$senha = $_POST['senha'];
$funcao = $_POST['funcao'];

$stmt = $conn->prepare(query: "SELECT id FROM Utilizadores WHERE username = ? OR email = ?");
$stmt->bind_param("ss", $username, $email);
$stmt->execute();
$result = $stmt->get_result();
if ($result->fetch_assoc()) {
    die("Usuário ou email já existem.");
}


$senha_hash = password_hash($senha, PASSWORD_DEFAULT);

// Inserir utilizador
$stmt = $conn->prepare(query: "INSERT INTO Utilizadores (nome, apelido, email, telefone, username, senha, funcao) VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sssssss", $nome, $apelido, $email, $telefone, $username, $senha_hash, $funcao);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    echo "Cadastro realizado com sucesso. <a href='login.html'>Clique aqui para fazer login</a>.";
} else {
    echo "Erro ao cadastrar.";
}

$stmt->close();
$conn->close();
?>