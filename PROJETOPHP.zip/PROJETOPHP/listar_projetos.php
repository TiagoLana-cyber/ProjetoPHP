<?php
// Conexão ao banco de dados
$host='localhost:3306'; 
$db_user='root'; 
$db='empresa_web';

$conn = new mysqli(hostname: $host, username: $db_user, database: $db);

if ($conn->connect_error) {
    die(json_encode(['status'=>'error', 'message'=>'Erro na conexão: ' . $conn->connect_error]));
}


$result = $conn->query("SELECT nome, descricao, tecnologia, data_inicio, data_conclusao, foto, tempo_estimado FROM Projetos");

// Lista de projetos
$projetos = [];

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $projetos[] = $row;
    }
}

$conn->close();


echo json_encode($projetos);
?>