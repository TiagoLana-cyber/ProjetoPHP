<?php
$host='localhost:3306'; 
$db_user='root';    
$db='empresa_web';

$conn = new mysqli(hostname: $host, username: $db_user,  database: $db);

if ($conn->connect_error) {
    die(json_encode(['status'=>'error', 'message'=>'Erro na conexão']));
}

$nome = $_POST['nome'];
$descricao = $_POST['descricao'];
$tecnologia = $_POST['tecnologia'];
$data_inicio = $_POST['data_inicio'];
$data_conclusao = $_POST['data_conclusao'];
$tempo_estimado = $_POST['tempo_estimado'];


if ($_FILES['foto']['error'] == 0) {
    $ext = strtolower(pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION));
    $novo_nome = uniqid() . "." . $ext;
    if (!is_dir("fotos")) {
        mkdir("fotos");
    }
    $destino = "fotos/" . $novo_nome;
    move_uploaded_file($_FILES['foto']['tmp_name'], $destino);
} else {
    $destino = null;
}

$stmt = $conn->prepare("INSERT INTO Projetos (nome, descricao, tecnologia, data_inicio, data_conclusao, foto, tempo_estimado) VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssssi", $nome, $descricao, $tecnologia, $data_inicio, $data_conclusao, $destino, $tempo_estimado);

if ($stmt->execute()) {
    echo json_encode(['status'=>'success']);
} else {
    echo json_encode(['status'=>'error', 'message'=>'Erro ao cadastrar']);
}

$stmt->close();
$conn->close();
?>