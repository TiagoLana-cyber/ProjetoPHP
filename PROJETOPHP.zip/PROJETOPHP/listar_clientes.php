<?php

$host='localhost:3306'; 
$db_user='root';   
$db='empresa_web';

$conn = new mysqli(hostname: $host, username: $db_user, database: $db);
if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}


$result = $conn->query(query: "SELECT nome, email, telefone, endereco FROM Clientes");
$clientes = [];

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $clientes[] = $row;
    }
}
$conn->close();

echo json_encode(value: $clientes);
?>