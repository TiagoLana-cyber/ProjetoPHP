<?php
session_start();

$host = 'localhost:3306'; 
$db_user = 'root'; 
$db_name = 'empresa_web';

$conn = new mysqli(hostname: $host, username: $db_user , database: $db_name);
if ($conn->connect_error) {
    die('Erro de conexão: ' . $conn->connect_error);
}

$username = $_POST['username'];
$senha = $_POST['senha'];

$stmt = $conn->prepare(query: "SELECT * FROM Utilizadores WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    // Verifica senha
    if (password_verify(password: $senha, hash: $row['senha'])) {
        $_SESSION['user_id'] = $row['id'];
        $_SESSION['username'] = $row['username'];
        $_SESSION['funcao'] = $row['funcao'];
        header('Location: area_restrita.php');
        exit();
    } else {
        echo 'Credenciais inválidas.';
    }
} else {
    echo 'Usuário não encontrado.';
}

$stmt->close();
$conn->close();
?>