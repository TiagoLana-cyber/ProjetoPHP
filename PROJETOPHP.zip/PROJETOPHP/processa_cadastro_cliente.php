<?php
$host='localhost:3306';
$db_user='root';   
$db='empresa_web';

$conn = new mysqli(hostname: $host, username: $db_user, database: $db);
if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}

$nome = $_POST['nome'];
$email = $_POST['email'];
$telefone = $_POST['telefone'];
$endereco = $_POST['endereco'];


$checkStmt = $conn->prepare("SELECT id FROM Clientes WHERE email = ?");
$checkStmt->bind_param("s", $email);
$checkStmt->execute();
$result = $checkStmt->get_result();
if ($result->fetch_assoc()) {
    die("Este email já está cadastrado. <a href='cadastro_cliente.php'>Tentar novamente</a>");
}
$checkStmt->close();


$stmt = $conn->prepare("INSERT INTO Clientes (nome, email, telefone, endereco) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $nome, $email, $telefone, $endereco);

if ($stmt->execute()) {
    
    header("Location: index.html");
    exit();
} else {
    echo "Erro ao cadastrar cliente.";
}

$stmt->close();
$conn->close();
?>